# Mini Doom (Pygame Version)

A simple Doom-style raycasting shooter built with **Python + Pygame**.

## 🎮 Features
- Raycasting 3D walls
- Enemies that move and attack
- Shooting with limited ammo
- Health system (you can die!)
- Touchscreen controls (for mobile / iPad with Pythonista/Pydroid)

---

## ▶️ How to Run

1. Install Python 3.8+
2. Install pygame:
   ```bash
   pip install pygame
   ```
3. Run the game:
   ```bash
   python mini_doom.py
   ```

---

## 📱 Touch Controls (iPad/Android)
- **Left side** → Move forward
- **Right side** → Turn view
- **Far right corner** → Shoot

---

## 💾 Repository Setup (GitHub)
1. Create a new repository on GitHub (public).
2. Upload `mini_doom.py` and `README.md` (or just drag this zip).
3. Commit changes.

Now you have a Pygame Doom clone stored in your GitHub! 🎉

---

Made for fun with ❤️ using Python and Pygame.
